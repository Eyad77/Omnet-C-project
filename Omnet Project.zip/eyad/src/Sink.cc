//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include "Sink.h"

namespace eyad {

Define_Module(Sink);

void Sink::initialize()
{
    lastArrival = simTime();
    iaTimeHistogram.setName("interarrival times");
    arrivalsVector.setName("arrivals");
    arrivalsVector.setInterpolationMode(cOutVector::NONE);
    countcollision =0;
    countsuccess = 0;
    idleslots = 0;
    counter = 0;
}

void Sink::handleMessage(cMessage *msg)
{
    if(lastArrival!=simTime()){
    countsuccess++;
    }
    simtime_t d = simTime() - lastArrival;
    EV << "Received " << msg->getName() << endl;
    if(lastArrival == simTime()){
        countcollision = countcollision +1;
        bubble("there is collision");
        EV<<countcollision;
        if(countsuccess>0){
        countsuccess--;}
    }
    delete msg;
    iaTimeHistogram.collect(d);
    arrivalsVector.record(1);
    counter++;
    lastArrival = simTime();
}

void Sink::finish()
{
    recordStatistic(&iaTimeHistogram);
    idleslots = (ceil(simTime().dbl()))-countsuccess-countcollision;
    recordScalar("#idleslots",idleslots);
    throughput = (countsuccess)/(simTime());
    recordScalar("#throughput",throughput);
    recordScalar("#collisionCount",countcollision);
    recordScalar("#Success",countsuccess);

}

}; // namespace
