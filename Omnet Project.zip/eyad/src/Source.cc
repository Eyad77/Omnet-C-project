//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include "Source.h"

namespace eyad {

Define_Module(Source);

Source::Source()
{
    timerMessage = NULL;
}

Source::~Source()
{
    cancelAndDelete(timerMessage);
}

void Source::initialize()
{
    timerMessage = new cMessage("timer");
    double m= par("sendInterval").doubleValue();
    lastarrival = 0;
    scheduleAt(simTime()+ceil(m), timerMessage);
    i=0;
}

void Source::handleMessage(cMessage *msg)
{
    ASSERT(msg==timerMessage);
    double m= par("sendInterval").doubleValue();
    cMessage *job = new cMessage("job");
    //recordScalar("#qlength",queue.length());
    if(lastarrival==simTime()){
        queue.insert(job);
        recordScalar("qlength",queue.length());

        while(true){

          if(queue.isEmpty()){
              break;
          }
          else{
              if(i<ceil(m)){

              x = check_and_cast<cMessage*>(queue.pop());
              send(x,"out");
              scheduleAt(simTime()+1, timerMessage);
              }
          }

          i++;
        }

    }else{
    queue.insert(job);

    x = check_and_cast<cMessage*>(queue.pop());

    recordScalar("qlength",queue.length());
    send(x,"out");
    scheduleAt(simTime()+ceil(m), timerMessage);
    }


    lastarrival = simTime();
}

}; // namespace
